import java.util.Scanner;
public class Main {
    public static void main(String[] args){
        Scanner sc= new Scanner(System.in);
        try{
            System.out.println("Ingrese un numero entero:");
            String numero=sc.nextLine();
            int numeros=Integer.parseInt(numero);
            double resultado = 100/numeros;
            System.out.println("Resultado:"+resultado);
        }catch (ArithmeticException e){
            System.out.println("No se puede dividir para cero");
        }catch (NumberFormatException e){
            System.out.println("Debe ingresar un numero valido");
        }finally {
            System.out.println("Programa finalizado");
        }
        sc.close();
    }
}