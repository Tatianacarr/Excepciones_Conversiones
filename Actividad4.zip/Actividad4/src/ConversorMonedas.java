public class ConversorMonedas {

    public double convertir(String monedaOrigen,
                            String monedaDestino,
                            double cantidad)
            throws MonedaNoSoportadaException {

        if ((!monedaOrigen.equalsIgnoreCase("USD") &&
                !monedaOrigen.equalsIgnoreCase("EUR")) ||

                (!monedaDestino.equalsIgnoreCase("USD") &&
                        !monedaDestino.equalsIgnoreCase("EUR"))) {

            throw new MonedaNoSoportadaException(
                    "Error: moneda no soportada.");
        }
        double tasa = 1.0;

        if (monedaOrigen.equalsIgnoreCase("USD") &&
                monedaDestino.equalsIgnoreCase("EUR")) {

            tasa = 0.92;
        }

        else if (monedaOrigen.equalsIgnoreCase("EUR") &&
                monedaDestino.equalsIgnoreCase("USD")) {

            tasa = 1.09;
        }

        else {
            tasa = 1.0;
        }

        return cantidad * tasa;
    }
}