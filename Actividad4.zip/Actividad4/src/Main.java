import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        ConversorMonedas conversor = new ConversorMonedas();

        try {

            System.out.print("Ingrese moneda origen (USD/EUR): ");
            String origen = sc.nextLine();

            System.out.print("Ingrese moneda destino (USD/EUR): ");
            String destino = sc.nextLine();

            System.out.print("Ingrese cantidad: ");
            String cantidadTexto = sc.nextLine();
            double cantidad = Double.parseDouble(cantidadTexto);
            double resultado =
                    conversor.convertir(origen, destino, cantidad);
            System.out.println(
                    "Resultado: " +
                            String.format("%.2f", resultado));

        } catch (NumberFormatException e) {

            System.out.println(
                    "Error: debe ingresar una cantidad válida.");

        } catch (MonedaNoSoportadaException e) {

            System.out.println(e.getMessage());

        } finally {

            System.out.println(
                    "Programa finalizado.");
        }

        sc.close();
    }
}
