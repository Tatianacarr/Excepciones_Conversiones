public class Main {
    public static void main(String[] args){
        try{
            Estudiante e1= new Estudiante("Angui",20,9.5);
            e1.mostrar();
            Estudiante e2= new Estudiante("Karen",-9,8.7);
            e2.mostrar();
            Estudiante e3=new Estudiante("Sergio",22,9.0);
            e3.mostrar();

        }catch (EdadInvalidaException e){
            System.out.println("Se produjo una excepcion personalizada");
            System.out.println(e.getMessage());
        }

    }
}