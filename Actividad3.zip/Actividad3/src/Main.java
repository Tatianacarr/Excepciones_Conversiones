public class Main {
    public static void main(String[] args){
        System.out.println("Parte convercion impliccita");
        byte b =10;
        short s=b;
        int i=s;
        long l=i;
        float f=l;
        double d=f;
        System.out.println("Byte:"+b);
        System.out.println("Short:"+s);
        System.out.println("Int:"+i);
        System.out.println("Long:"+l);
        System.out.println("Float:"+f);
        System.out.println("Double:"+d);

        System.out.println("Casting Explicito");
        double numero=45.89;
        float numFloat=(float)numero;
        short numShot=(short)numero;
        byte numByte=(byte)numero;
        System.out.println("Double original:"+numero);
        System.out.println("Float:"+numFloat);
        System.out.println("Short:"+numShot);
        System.out.println("Byte:"+numByte);

        System.out.println("String a tipos");
        String textoEntero="2024";
        String textoDouble="96.8";
        String textoBoolean="false";
        int entero=Integer.parseInt(textoEntero);
        double decimal=Double.parseDouble(textoDouble);
        boolean boleano=Boolean.parseBoolean(textoBoolean);
        String s1=String.valueOf(entero);
        String s2=Double.toString(decimal);
        String a3=Boolean.toString(boleano);


        System.out.println("Conversion");
        System.out.println(s1);
        System.out.println(s2);
        System.out.println(a3);
        Animal a=new Perro();
        a.sonido();
        if (a instanceof Perro){
            Perro p=(Perro) a;
            p.ladrar();
        }
    }
}
