public class Perro  extends Animal{
    @Override
    public void sonido(){
        System.out.println("El perro ladra");
    }
    public void ladrar(){
        System.out.println("guau guau");
    }
}
